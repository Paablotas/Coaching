
<?php

?>
<script>mw.lib.require('bootstrap3');</script>
<module type="admin/modules/templates"  />