<?php

$config = array();
$config['name'] = "Boxes";
$config['author'] = "Digital Dreamer";
$config['ui'] = true;
$config['version'] = 0.01;
