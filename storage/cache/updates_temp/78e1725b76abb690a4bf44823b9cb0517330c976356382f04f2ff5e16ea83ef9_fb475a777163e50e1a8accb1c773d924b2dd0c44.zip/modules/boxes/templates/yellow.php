<?php
/*
type: layout
name: yellow
*/

?>
<?php $color = get_option('color', $params['id']);?>
    <div class="col-md-12 col-sm-6">
        <div class="service-block service-block-yellow edit" rel="services<?php print $params['id']?>" field="services">
            <h2 class="heading-md">Yellow Box</h2>
            <p>Donec id elit non mi porta gravida at eget metus id elit mi egetine usce dapibus elit nondapibus</p>
        </div>
    </div>
