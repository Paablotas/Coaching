<?php

$config = array();
$config['name'] = "Panels";
$config['author'] = "Digital Dreamer";
$config['ui'] = true;
$config['version'] = 0.01;
