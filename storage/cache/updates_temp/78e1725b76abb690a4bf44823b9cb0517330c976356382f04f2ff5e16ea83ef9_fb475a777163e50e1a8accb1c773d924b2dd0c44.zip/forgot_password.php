<?php

/*



*/


?>
<?php include template_dir(). "header.php"; ?>
<div id="content">
     <div class="container edit"  field="content" rel="content">
        <div class="small-layout headed-box" id="sign-box">
            <module="users/forgot_password" />
        </div>
     </div>
 </div>
<?php include template_dir(). "footer.php"; ?>
