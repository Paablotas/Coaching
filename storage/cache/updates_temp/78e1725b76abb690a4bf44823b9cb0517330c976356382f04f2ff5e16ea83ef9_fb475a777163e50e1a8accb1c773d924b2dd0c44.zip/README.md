# Bootstrap3 Microweber template


This is a template based on the Bootstrap 3 framework.

Install this template in 'userfiles/templates/bootstrap3'