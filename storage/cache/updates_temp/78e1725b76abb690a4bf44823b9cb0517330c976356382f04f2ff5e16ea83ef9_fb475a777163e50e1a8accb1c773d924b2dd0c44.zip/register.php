<?php

/*

  
*/

?>
<?php include template_dir(). "header.php"; ?>

<div id="content">
    <div class="container">
        <div class="small-layout headed-box" id="sign-box">
             <module type="users/register" />
         </div>
    </div>
</div>









<?php include template_dir(). "footer.php"; ?>
