<?php

/*

  THIS FILE WILL LOAD WHEN YOU OPEN A CONTENT WITH SUBTYPE PRODUCT 
  
  that is added to a page that does not use the shop layout
  
  
  
  Curently it loads the default layout for the product, but you can use it for custom design.

*/

?>
<?php include template_dir(). "layouts/shop_inner.php";  ?>
